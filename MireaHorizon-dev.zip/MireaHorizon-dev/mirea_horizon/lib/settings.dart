class LocalKeys {
  static const localKey = 'locale';
  static const themKey = 'theme';
  static const openKey = 'isOpen';
}
