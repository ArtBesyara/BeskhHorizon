package com.example.mirea_horizon

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
