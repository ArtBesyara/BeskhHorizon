import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:go_router/go_router.dart';
import 'package:igce_app/presentation/app/app_initializer.dart';
import 'package:igce_app/presentation/app/dependecies_initializer.dart';
import 'package:igce_app/presentation/bloc/theme_bloc/theme_cubit.dart'
    as app_theme;
// import 'package:igce_app/presentation/igce_app_theme/theme/dark_theme.dart';
// import 'package:igce_app/presentation/igce_app_theme/theme/light_theme.dart';
import 'package:igce_app/presentation/router/main_router.dart';
import 'package:igce_app/presentation/router/routes/data_source/route_const.dart';
import 'package:igce_theme/igce_theme.dart';
// import 'package:igce_theme/ui/ui.dart';
// import 'package:igce_app/presentation/bloc/theme_bloc/theme_bloc.dart';
// import 'package:igce_app/presentation/router/main_router.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  final GoRouter router = createAppRoute();
  RouterConst.router = router;
  await DependeciesInitializer.setup();
  runApp(MyApp(router: router));
}

class MyApp extends StatelessWidget {
  final GoRouter router;
  const MyApp({super.key, required this.router});

  @override
  Widget build(BuildContext context) {
    return AppInitializer(
      child: BlocBuilder<app_theme.ThemeCubit, app_theme.ThemeState>(
          builder: (context, state) {
        return MaterialApp.router(
          title: 'Flutter Demo',
          theme: IgceAppTheme.lightTheme,
          darkTheme: IgceAppTheme.darkTheme,
          themeMode: state.themeMode,
          routerConfig: router,
        );
      }),
    );
  }
}
