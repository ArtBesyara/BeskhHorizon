import 'package:flutter/widgets.dart';
import 'package:go_router/go_router.dart';
import 'package:igce_app/presentation/features/videos/videos.dart';

import '../../../features/test/test_page.dart';
import 'video_routes_constants.dart';

class VideoRouter extends StatefulShellBranch {
  VideoRouter()
      : super(
            initialLocation: VideoRoutes.base(),
            navigatorKey: GlobalKey<NavigatorState>(),
            routes: <RouteBase>[
              GoRoute(
                  path: VideoRoutes.base(),
                  builder: (BuildContext context, GoRouterState state) =>
                      const VideosScreen(),
                  routes: [
                    GoRoute(
                      path: VideoRoutes.details(),
                      builder: (context, state) =>
                          TestsScreen(nameTitle: 'video'),
                    )
                  ])
            ]);
}
