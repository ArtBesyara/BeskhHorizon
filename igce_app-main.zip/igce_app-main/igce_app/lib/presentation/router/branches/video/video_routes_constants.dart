import 'package:igce_app/presentation/router/routes/data_source/route_const.dart';

class VideoRoutes {
  static const base = RouterConst("/videos");
  static const details = RouterConst("details", base: VideoRoutes.base);
}
