import 'package:flutter/widgets.dart';
import 'package:go_router/go_router.dart';
import 'package:igce_app/presentation/features/photo/photo.dart';

import '../../../features/test/test_page.dart';
import 'photo_routes_constants.dart';

class PhotoRouter extends StatefulShellBranch {
  PhotoRouter()
      : super(
            initialLocation: PhotoRoutes.base(),
            navigatorKey: GlobalKey<NavigatorState>(),
            routes: <RouteBase>[
              GoRoute(
                  path: PhotoRoutes.base(),
                  builder: (BuildContext context, GoRouterState state) =>
                      const PhotoScreen(),
                  routes: [
                    GoRoute(
                      path: PhotoRoutes.details(),
                      builder: (context, state) =>
                          TestsScreen(nameTitle: 'photo'),
                    )
                  ])
            ]);
}
