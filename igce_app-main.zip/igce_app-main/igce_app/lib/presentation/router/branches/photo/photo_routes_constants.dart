import 'package:igce_app/presentation/router/routes/data_source/route_const.dart';

class PhotoRoutes {
  static const base = RouterConst("/photo");
  static const details = RouterConst("details", base: PhotoRoutes.base);
}
