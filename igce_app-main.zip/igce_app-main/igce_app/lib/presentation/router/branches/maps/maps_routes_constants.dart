import 'package:igce_app/presentation/router/routes/data_source/route_const.dart';

class MapsRoutes {
  static const base = RouterConst("/maps");
  static const details = RouterConst("details", base: MapsRoutes.base);
}
