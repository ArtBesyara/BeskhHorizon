import 'package:flutter/widgets.dart';
import 'package:go_router/go_router.dart';
import 'package:igce_app/data/models/maps/station_model.dart';
import 'package:igce_app/presentation/bloc/theme_bloc/bloc.dart';
import 'package:igce_app/presentation/features/maps/maps_detail.dart';

import '../../../features/maps/maps.dart';
import '../../../features/test/test_page.dart';
import 'maps_routes_constants.dart';

class MapsRouter extends StatefulShellBranch {
  MapsRouter()
      : super(
            initialLocation: MapsRoutes.base(),
            navigatorKey: GlobalKey<NavigatorState>(),
            routes: <RouteBase>[
              GoRoute(
                  path: MapsRoutes.base(),
                  builder: (BuildContext context, GoRouterState state) =>
                      const MapsScreen(),
                  routes: [
                    GoRoute(
                        path: MapsRoutes.details(),
                        builder: (context, state) {
                          final args = state.extra
                              as Map<String, dynamic>; // Извлекаем параметры
                          final station = args['station']
                              as StationModel; // Получаем StationModel
                          final appBar = args['appBar'] as AppBar;
                          return MapsDetailScreen(
                            appBar: appBar,
                            station: station,
                          );
                        })
                  ])
            ]);
}
