import 'package:flutter/widgets.dart';
import 'package:go_router/go_router.dart';
import 'package:igce_app/presentation/features/method/method.dart';

import '../../../features/test/test_page.dart';
import 'method_routes_constants.dart';

class MethodRouter extends StatefulShellBranch {
  MethodRouter()
      : super(
            initialLocation: MethodRoutes.base(),
            navigatorKey: GlobalKey<NavigatorState>(),
            routes: <RouteBase>[
              GoRoute(
                  path: MethodRoutes.base(),
                  builder: (BuildContext context, GoRouterState state) =>
                      const MethodScreen(),
                  routes: [
                    GoRoute(
                      path: MethodRoutes.details(),
                      builder: (context, state) =>
                          TestsScreen(nameTitle: 'method'),
                    )
                  ])
            ]);
}
