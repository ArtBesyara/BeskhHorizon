import 'package:igce_app/presentation/router/routes/data_source/route_const.dart';

class MethodRoutes {
  static const base = RouterConst("/method");
  static const details = RouterConst("details", base: MethodRoutes.base);
}
