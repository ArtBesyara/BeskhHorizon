import 'package:flutter/widgets.dart';
import 'package:go_router/go_router.dart';
import 'package:igce_app/presentation/features/welcome/welcome.dart';

import '../../../features/test/test_page.dart';
import 'welcome_routes_constants.dart';

class WelcomeRouter extends StatefulShellBranch {
  WelcomeRouter()
      : super(
            initialLocation: WelcomeRoutes.base(),
            navigatorKey: GlobalKey<NavigatorState>(),
            routes: <RouteBase>[
              GoRoute(
                  path: WelcomeRoutes.base(),
                  builder: (BuildContext context, GoRouterState state) =>
                      const WelcomeScreen(),
                  routes: [
                    GoRoute(
                      path: WelcomeRoutes.details(),
                      builder: (context, state) =>
                          TestsScreen(nameTitle: 'welcome'),
                    )
                  ])
            ]);
}
