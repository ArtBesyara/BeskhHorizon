import 'package:igce_app/presentation/router/routes/data_source/route_const.dart';

class WelcomeRoutes {
  static const base = RouterConst("/welcome");
  static const details = RouterConst("details", base: WelcomeRoutes.base);
}
