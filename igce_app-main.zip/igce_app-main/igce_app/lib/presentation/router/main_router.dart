import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:igce_app/presentation/ui/base/base.dart';
import 'branches/welcome/welcome.dart';
import 'branches/maps/maps.dart';
import 'branches/photo/photo.dart';
import 'branches/video/video.dart';
import 'branches/method/method.dart';
import 'routes/base/base.dart';

final GlobalKey<NavigatorState> _rootNavigatorKey = GlobalKey<NavigatorState>();

GoRouter createAppRoute() {
  return GoRouter(
    navigatorKey: _rootNavigatorKey,
    initialLocation: BaseRoutes.base(),
    routes: [
      StatefulShellRoute.indexedStack(
          builder: (BuildContext context, GoRouterState state,
              StatefulNavigationShell navigationShell) {
            return DefaultNavBar(navigationShell: navigationShell);
          },
          branches: <StatefulShellBranch>[
            WelcomeRouter(),
            MapsRouter(),
            VideoRouter(),
            MethodRouter(),
            PhotoRouter(),
          ])
    ],
  );
}

// final router = GoRouter(initialLocation: '/welcome', routes: [
//   StatefulShellRoute.indexedStack(
//       builder: (context, state, navigationShell) =>
//           RootScreen(navigationShell: navigationShell),
//       branches: [
//         StatefulShellBranch(routes: [
//           GoRoute(
//             path: '/maps',
//             builder: (context, state) => const MapsScreen(),
//           )
//         ]),
//         StatefulShellBranch(routes: [
//           GoRoute(
//             path: '/method',
//             builder: (context, state) => const VideosScreen(),
//           )
//         ]),
//         StatefulShellBranch(routes: [
//           GoRoute(
//             path: '/photo',
//             builder: (context, state) => const MethodScreen(),
//           )
//         ]),
//         StatefulShellBranch(routes: [
//           GoRoute(
//             path: '/videos',
//             builder: (context, state) => const PhotoScreen(),
//           )
//         ]),
//         StatefulShellBranch(routes: [
//           GoRoute(
//             path: '/welcome',
//             builder: (context, state) => const WelcomeScreen(),
//           )
//         ]),
//       ])
// ]);
