import '../data_source/route_const.dart';

class BaseRoutes {
  static const base = RouterConst("/welcome");
}
