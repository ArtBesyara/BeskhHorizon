import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:igce_app/data/repositories/maps_repo/maps_repo.dart';
import 'package:igce_app/presentation/bloc/maps_bloc/maps_state.dart';
import 'package:igce_app/presentation/bloc/maps_bloc/maps_event.dart';

class MapsBloc extends Bloc<MapsEvent, MapsState> {
  final MapsRepo mapsRepository;

  MapsBloc(this.mapsRepository) : super(MapsInitial()) {
    on<LoadingMaps>((event, emit) async {
      emit(MapsLoading());
      try {
        final maps = await mapsRepository.fetchStation();
        emit(MapsLoaded(maps));
      } catch (e) {
        emit(MapsError(e.toString()));
      }
    });
  }
}
