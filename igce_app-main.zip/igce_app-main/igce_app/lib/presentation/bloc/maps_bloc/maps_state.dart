import 'package:igce_app/data/models/maps/station_model.dart';

abstract class MapsState {}

class MapsInitial extends MapsState {}

class MapsLoading extends MapsState {}

class MapsLoaded extends MapsState {
  final List<StationModel> stations;

  MapsLoaded(this.stations);
}

class MapsError extends MapsState {
  final String message;

  MapsError(this.message);
}
