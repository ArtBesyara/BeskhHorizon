abstract class MapsEvent {}

class LoadingMaps extends MapsEvent {}
