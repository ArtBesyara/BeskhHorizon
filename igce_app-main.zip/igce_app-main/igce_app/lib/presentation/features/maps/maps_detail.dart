import 'package:flutter/widgets.dart';
import 'package:igce_app/data/models/maps/station_model.dart';
import 'package:igce_app/presentation/bloc/theme_bloc/bloc.dart';
import 'package:igce_theme/ui/ui.dart';
import 'package:url_launcher/url_launcher.dart';
// import 'package:webview_flutter/webview_flutter.dart';

import '../base_widgets/custom_widget.dart';

class MapsDetailScreen extends StatelessWidget {
  final AppBar appBar;
  final StationModel station;
  MapsDetailScreen({super.key, required this.appBar, required this.station});
  @override
  Widget build(BuildContext context) {
    print(station.urlTitle);
    return CustomWidget(
        appBar: appBar,
        body: Center(
          child: SingleChildScrollView(
            child: Column(
              children: [
                // const SizedBox(height: 15),
                Container(
                  padding: const EdgeInsets.all(10.0),
                  child: ClipRRect(
                    borderRadius: BorderRadius.circular(20.0),
                    child: Image.network(
                      station.img!,
                      fit: BoxFit.cover,
                    ),
                  ),
                ),
                const SizedBox(height: 15),
                ArrowCard(
                  title: 'Фото',
                  onTap: () => {},
                ),
                const SizedBox(height: 5),
                ArrowCard(
                  title: 'Видео',
                  onTap: () => {},
                ),
                const SizedBox(height: 10),
                ElevatedButton50(
                    text: station.urlTitle!,
                    onPressed: () => _launchInBrowser(Uri.parse(station.url!))),
                const SizedBox(height: 10),
                // ElevatedButton(
                //     onPressed: () => {}, child: const Text('О сети ЕМЕП')),
                const SizedBox(height: 10),
                Text(
                  station.description.toString(),
                  textAlign: TextAlign.center,
                ),
              ],
            ),
          ),
        ));
  }

  Future<void> _launchInBrowser(Uri url) async {
    if (!await launchUrl(
      url,
      mode: LaunchMode.externalApplication,
    )) {
      throw Exception('Could not launch $url');
    }
  }
}
