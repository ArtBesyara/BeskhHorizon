import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_map/flutter_map.dart';
import 'package:flutter_map_marker_cluster/flutter_map_marker_cluster.dart';
import 'package:go_router/go_router.dart';
import 'package:igce_app/data/models/maps/station_model.dart';
import 'package:igce_app/data/repositories/repositories.dart';
import 'package:igce_app/main.dart';
import 'package:igce_app/presentation/features/base_widgets/custom_widget.dart';
import 'package:igce_theme/extensions/context_extension.dart';
import 'package:igce_theme/igce_theme.dart';
import 'package:latlong2/latlong.dart';

import '../../bloc/maps_bloc/bloc.dart';

class MapsScreen extends StatefulWidget {
  const MapsScreen({super.key});

  @override
  _MapsScreenState createState() => _MapsScreenState();
}

class _MapsScreenState extends State<MapsScreen> {
  final MapController _mapController = MapController();
  double _zoom = 13.0;
  bool _isFirstImage = true;

  void increaseZoom() {
    setState(() {
      _zoom++;

      _mapController.move(_mapController.camera.center, _zoom);
    });
  }

  void decreaseZoom() {
    setState(() {
      if (_zoom > 1) {
        _zoom--;
        _mapController.move(_mapController.camera.center, _zoom);
      }
    });
  }

  void _toggleImage() {
    setState(() {
      _isFirstImage = !_isFirstImage;
    });
  }

  @override
  Widget build(BuildContext context) {
    final mapsRepository = MapsRepo('http://127.0.0.1:8000/api/stations');
    //TODO инициализировать блок через все блоки
    return BlocProvider(
      create: (context) => MapsBloc(mapsRepository)..add(LoadingMaps()),
      child: CustomWidget(
          appBar: AppBar(
            title: const Text('maps'),
            backgroundColor: context.colorTheme.mainClickColor,
            centerTitle: true,
            actions: [
              IconButton(
                  onPressed: _toggleImage,
                  icon: _isFirstImage
                      ? const Icon(Icons.list_alt)
                      : const Icon(Icons.location_on))
            ],
          ),
          body: BlocBuilder<MapsBloc, MapsState>(builder: (context, state) {
            if (state is MapsLoading) {
              return const Center(child: CircularProgressIndicator());
            } else if (state is MapsError) {
              print(state.message);
              return Center(child: Text('Error: ${state.message}'));
            } else if (state is MapsLoaded) {
              final stations = state.stations;
              return _isFirstImage ? _stationMap(stations) : _listMap(stations);
            } else {
              return const Center(child: Text('Unexpected state'));
            }
          })),
    );
  }

  Widget _stationMap(List<StationModel> stations) {
    return Stack(
      children: [
        Expanded(
          child: FlutterMap(
            mapController: _mapController,
            options: MapOptions(
                initialCenter:
                    LatLng(stations[0].latitude, stations[0].longitude)),
            children: [
              TileLayer(
                urlTemplate: 'https://tile.openstreetmap.org/{z}/{x}/{y}.png',
                userAgentPackageName: 'com.example.igce_app',
              ),
              MarkerClusterLayerWidget(
                  options: MarkerClusterLayerOptions(
                      size: const Size(50, 50),
                      maxClusterRadius: 50,
                      markers: _getMarks(stations),
                      builder: (_, markers) {
                        return _ClusterMarker(
                            markersLength: stations.length.toString());
                      })),
              // MarkerLayer(markers: _getMarks(stations)),
            ],
          ),
        ),
        Positioned(
          bottom: 20,
          right: 20,
          child: Column(
            mainAxisAlignment: MainAxisAlignment.end,
            children: [
              FloatingActionButton(
                onPressed: increaseZoom,
                child: const Icon(Icons.add),
              ),
              const SizedBox(height: 10),
              FloatingActionButton(
                onPressed: decreaseZoom,
                child: const Icon(Icons.remove),
              ),
            ],
          ),
        )
      ],
    );
  }

  Widget _listMap(List<StationModel> stations) {
    return ListView.builder(
        itemCount: stations.length,
        itemBuilder: (BuildContext context, int index) {
          return ArrowCard(
            // icon: Icons.add_location_sharp,
            title: stations[index].title!,
            onTap: () {
              context.go('/maps/details', extra: _goPage(stations[index]));
            },
          );
        });
  }

  List<Marker> _getMarks(List<StationModel> stations) {
    return List.generate(
      stations.length,
      (index) => Marker(
        point: LatLng(stations[index].latitude, stations[index].longitude),
        child: IconButton(
            onPressed: () => _showModalDialog(stations[index]),
            icon: const Icon(Icons.location_on, color: Colors.red, size: 30)),
        width: 50,
        height: 50,
        alignment: Alignment.center,
      ),
    );
  }

  void _showModalDialog(StationModel station) {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text(
            station.title.toString(),
            textAlign: TextAlign.center,
          ),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                padding: const EdgeInsets.all(5.0),
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(20.0),
                  child: Image.network(
                    station.img!,
                    fit: BoxFit.cover,
                  ),
                ),
              ),
              const SizedBox(height: 10),
              Text(
                station.description.toString(),
                textAlign: TextAlign.center,
                maxLines: 5,
                overflow: TextOverflow.ellipsis,
              ),
            ],
          ),
          actions: <Widget>[
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                TextButton(
                  child: const Text('Закрыть'),
                  onPressed: () {
                    Navigator.of(context).pop();
                  },
                ),
                TextButton(
                  child: const Text('Подробнее'),
                  onPressed: () {
                    context.go('/maps/details', extra: _goPage(station));
                    Navigator.of(context).pop();
                  },
                ),
              ],
            )
          ],
        );
      },
    );
  }

  Map<String, Object> _goPage(StationModel station) {
    final arguments = {
      'station': station,
      'appBar': AppBar(
        title: Text(station.title.toString()),
        centerTitle: true,
        backgroundColor: context.colorTheme.mainClickColor,
      ),
    };

    return arguments;
  }
}

/// Виджет для отображения кластера
class _ClusterMarker extends StatelessWidget {
  const _ClusterMarker({required this.markersLength});

  /// Количество маркеров, объединенных в кластер
  final String markersLength;

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: Colors.blue[200],
        shape: BoxShape.circle,
        border: Border.all(
          color: Colors.blue,
          width: 3,
        ),
      ),
      child: Center(
        child: Text(
          markersLength,
          style: TextStyle(
            color: Colors.blue[900],
            fontWeight: FontWeight.w700,
            fontSize: 18,
          ),
        ),
      ),
    );
  }
}
