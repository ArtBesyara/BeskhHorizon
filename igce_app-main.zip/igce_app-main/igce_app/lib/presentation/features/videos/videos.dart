import 'package:flutter/material.dart';
import 'package:igce_theme/extensions/context_extension.dart';

import '../base_widgets/custom_widget.dart';

class VideosScreen extends StatelessWidget {
  const VideosScreen({super.key});
  @override
  Widget build(BuildContext context) {
    return CustomWidget(
        appBar: AppBar(
          title: const Text('video'),
          backgroundColor: context.colorTheme.mainClickColor,
          centerTitle: true,
        ),
        body: const Center(
          child: Text('Videos'),
        ));
  }
}
