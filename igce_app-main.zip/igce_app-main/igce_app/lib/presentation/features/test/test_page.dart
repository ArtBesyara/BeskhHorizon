import 'package:flutter/material.dart';
import 'package:igce_theme/extensions/context_extension.dart';

import '../base_widgets/custom_widget.dart';

class TestsScreen extends StatelessWidget {
  final String nameTitle;
  TestsScreen({super.key, required this.nameTitle});
  @override
  Widget build(BuildContext context) {
    return CustomWidget(
        appBar: AppBar(
          title: Text(nameTitle),
          backgroundColor: context.colorTheme.mainClickColor,
          centerTitle: true,
        ),
        body: Center(
          child: Text(nameTitle),
        ));
  }
}
