// import 'package:flutter/material.dart';
// import 'package:flutter_bloc/flutter_bloc.dart';
// import 'package:go_router/go_router.dart';

// import '../../bloc/theme_bloc/theme_bloc.dart';

// class RootScreen extends StatelessWidget {
//   const RootScreen({super.key, required this.navigationShell});

//   final StatefulNavigationShell navigationShell;

//   @override
//   Widget build(BuildContext context) {
//     return BlocBuilder<ThemeBloc, ThemeState>(
//       builder: (context, state) {
//         var colorScheme = Theme.of(context).colorScheme;
//         return Scaffold(
//           body: navigationShell,
//           bottomNavigationBar: BottomNavigationBar(
//             type: BottomNavigationBarType.fixed,
//             selectedItemColor: colorScheme.primary,
//             unselectedItemColor: colorScheme.onSurface,
//             items: _buildBottomNavBarItems,
//             currentIndex: navigationShell.currentIndex,
//             onTap: (index) => navigationShell.goBranch(
//               index,
//               initialLocation: index == navigationShell.currentIndex,
//             ),
//           ),
//         );
//       },
//     );
//   }

//   List<BottomNavigationBarItem> get _buildBottomNavBarItems => [
//         const BottomNavigationBarItem(
//           icon: Icon(Icons.map),
//           label: 'Карты',
//         ),
//         const BottomNavigationBarItem(
//           icon: Icon(Icons.videocam_sharp),
//           label: 'Видео',
//         ),
//         const BottomNavigationBarItem(
//           icon: Icon(Icons.note),
//           label: 'Методики',
//         ),
//         const BottomNavigationBarItem(
//           icon: Icon(Icons.photo_album_outlined),
//           label: 'Фото',
//         ),
//         const BottomNavigationBarItem(
//           icon: Icon(Icons.start),
//           label: 'Приветствие',
//         ),
//       ];
// }
