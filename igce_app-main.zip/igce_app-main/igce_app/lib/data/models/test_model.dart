class TestModel {
  final int id;
  final String testParam;

  TestModel({required this.id, required this.testParam});
}
