import 'package:json_annotation/json_annotation.dart';

part 'station_model.g.dart'; // Генерируемый файл

@JsonSerializable()
class StationModel {
  final int id;
  final String? title;
  final String? description;
  final String? img;
  final String? url;
  final String? urlTitle;
  final double latitude;
  final double longitude;

  StationModel({
    required this.id,
    this.title,
    this.description,
    this.img,
    this.url,
    this.urlTitle,
    required this.latitude,
    required this.longitude,
  });

  // Функция для создания экземпляра Location из JSON
  factory StationModel.fromJson(Map<String, dynamic> json) =>
      _$StationModelFromJson(json);

  // Функция для преобразования экземпляра Location в JSON
  Map<String, dynamic> toJson() => _$StationModelToJson(this);
}
