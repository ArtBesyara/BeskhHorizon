import 'package:igce_app/data/dao/dao.dart';

class TestDaoRepoImpl implements Dao {
  final Dao dao;
  TestDaoRepoImpl(this.dao);

  @override
  Future<List> getAll() {
    // TODO: implement getAll
    throw UnimplementedError();
  }

  @override
  Future getById(int id) {
    // TODO: implement getById
    throw UnimplementedError();
  }
}
