import 'dart:convert';
import 'package:http/http.dart' as http;

import 'package:igce_app/data/dao/maps/maps_dao.dart';
import 'package:igce_app/data/models/maps/station_model.dart';

class MapsRepo implements MapsDao {
  final String apiUrl;

  MapsRepo(this.apiUrl);

  @override
  Future<List<StationModel>> fetchStation() async {
    final response = await http.get(Uri.parse(apiUrl));

    if (response.statusCode == 200) {
      print('Raw response: ${response.body}');
      final decodedResponse = utf8.decode(response.bodyBytes);
      List<dynamic> jsonResponse = json.decode(decodedResponse);
      print(jsonResponse);
      return jsonResponse
          .map((station) => StationModel.fromJson(station))
          .toList();
    } else {
      throw Exception('Failed to load locations');
    }
  }
}
