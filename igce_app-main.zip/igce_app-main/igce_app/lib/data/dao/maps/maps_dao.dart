import 'package:igce_app/data/models/maps/station_model.dart';

abstract class MapsDao {
  Future<List<StationModel>> fetchStation();
}
